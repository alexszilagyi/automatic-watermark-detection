# File for storing useful constants

class constants:
	
	#Watermark Size
	wmX = 155
	wmY = 30
